# Hospital da Luz — Oncologia Assistente (v6)
Mudanças pedidas:
- As **perguntas** do formulário mantêm-se visíveis.
- Em **todas** as especialidades, no fim do output é sempre mostrada a caixa **“Médicos — Oncologia Médica (Lisboa)”** (lista geral).

Mantém restantes regras: hábitos/razões pré-definidos, perguntas (IA), árvore de decisão para recomendação quando não houve consulta, associações ligadas à área, branding HDL.
